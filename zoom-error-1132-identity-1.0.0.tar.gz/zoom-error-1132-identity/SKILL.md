---
name: zoom-error-1132-identity
description: "Fix Zoom error 1132 by swapping the device identity."
version: 1.0.0
author: Michelangelo Marchiorello (mmarchio-a11y), Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [zoom, macos, hwid, identity, error-1132]
    related_skills: [zoom-clean-uninstall, computer-use]
---

# Zoom error 1132: device identity fix

Zoom's "Unable to sign in (Error code: 1132)" is a ban keyed to the Mac's hardware
identity, not to any local file or Keychain item. This skill diagnoses that and applies a
reversible, Zoom-only identity substitution so the app signs in, shows the avatar and can
host meetings again. It does not touch other apps, does not spoof anything system-wide,
and does not contact Zoom on the user's behalf.

## When to use

- Sign-in fails with 1132 while the account works in a browser or on another device.
- Every file, cache, preference and Keychain item for Zoom has already been deleted and
  the error survives a clean reinstall.
- A sandbox workaround (1132 Fixer and similar) gets you into meetings but there is no
  avatar and New meeting does nothing.

Don't use for: ordinary sign-in problems (wrong password, MFA, org restrictions), or when
the account itself is suspended. Check the account in a browser first.

## Root cause

Zoom builds its device id from IOKit `IOPlatformUUID` and `IOPlatformSerialNumber`.
Denying those two reads is exactly how the third-party fixers "work", which proves the
server matches on them. Nothing on disk stores the value, so deletion cannot help. See
`references/evidence.md` for the strings and sandbox profile that establish this.

Consequence: either Zoom support removes the device ban, or Zoom must be shown a
different, well-formed identity. Empty values (what a denial produces) give a degraded
session, which is why the sandbox trick loses the avatar and hosting.

## Prerequisites

- macOS on Apple Silicon (arm64). Intel Macs need the same approach but the `archType`
  query parameter is not required.
- Xcode Command Line Tools for `clang` (`xcode-select --install`).
- The user's approval: this deletes all local Zoom state, replaces the app bundle with a
  re-signed copy, disables Zoom's updater, and resets camera/mic/screen-recording
  permissions. State all four before running anything.
- A macOS administrator password at the GUI prompt. Never ask for or type it in chat.

## Procedure

1. **Confirm the live error.** Verify host with `terminal` (`scutil --get ComputerName`,
   `sw_vers`) and capture the Zoom window (use `computer_use`, `list_windows` then
   `capture` with `pid` and `window_id`). Done when the screenshot or the user confirms
   error 1132 at the email step.
2. **Wipe local state.** Run `terminal(command="python3 scripts/wipe_local_zoom_state.py")`
   with Zoom quit. Done when the printed manifest shows paths deleted and both
   `Zoom Safe Storage` and `Zoom Safe Meeting Storage` Keychain items reported absent.
   Leftover empty `com.apple.WebKit.*+us.zoom.xos` temp dirs are expected; macOS refuses
   to remove them.
3. **Build and install the patched bundle.** From the skill directory run:
   `terminal(command="osascript -e 'do shell script \"/bin/bash <abs path>/scripts/fix_zoom_1132_root.sh\" with administrator privileges'", timeout=600)`.
   It downloads the arm64 package, verifies the Zoom Developer ID and notarisation,
   installs it, builds the stub+shim bundle, swaps it in, re-signs, and disables the
   updater. Done when the log ends with `verify ok` and
   `/Applications/zoom.us.app/Contents/MacOS/zoom.us.bin` exists.
4. **Verify end to end.** Launch with `open -a /Applications/zoom.us.app`, confirm the
   shim is mapped (`vmmap <pid> | grep -c zoomidspoof` > 0), then enter the account email
   and press Next. Done when it advances to password/passkey instead of showing 1132, the
   avatar renders, and New meeting opens a meeting window.
5. **Hand over maintenance.** Tell the user that Zoom's updater is disabled and give them
   the reapply command for after a manual Zoom update
   (`scripts/reapply_after_update.sh`, installed into the identity directory).

## Quick reference

| Task | Command |
|---|---|
| Wipe local state | `python3 scripts/wipe_local_zoom_state.py` |
| Full install + patch | `osascript -e 'do shell script "/bin/bash <abs>/scripts/fix_zoom_1132_root.sh" with administrator privileges'` |
| Reapply after update | `osascript -e 'do shell script "/bin/bash \"/Library/Application Support/ZoomIdentity/reapply.sh\"" with administrator privileges'` |
| Proof shim is loaded | `vmmap $(pgrep -x zoom.us) \| grep -c zoomidspoof` |
| Rebuild shim only | `scripts/build_shim.sh /var/tmp/out` |

## Pitfalls

- **`dlsym(RTLD_NEXT, ...)` returns the interposer itself** inside a `__DATA,__interpose`
  section on current dyld. Calling it as a "real function" recurses until the process
  hangs. Read unknown properties through `IORegistryEntryCreateCFProperties` instead, and
  hold the re-entrancy guard across the whole call.
- **`LSEnvironment` with `DYLD_*` is refused by LaunchServices** (`open` fails with
  -10669) even with a valid signature. Inject through the stub binary, not the plist.
- **macOS App Management blocks edits inside an installed app** even as root: `mv`,
  `xattr` and `codesign` return Operation not permitted. Build the bundle in `/var/tmp`
  and replace the whole directory with `ditto`.
- **`https://zoom.us/client/latest/Zoom.pkg` serves the x86_64 build.** Use
  `?archType=arm64` or the result dies with "Bad CPU type in executable" on a Mac
  without Rosetta.
- `codesign` rejects stray Finder metadata: `xattr -cr` before signing.
- The identity must stay fixed across reinstalls. Never regenerate it on reapply, or the
  user is back to a brand new device with the same risk.
- A filename containing "zoom" is not ownership proof. Do not delete `Documents/Zoom`
  recordings, browser data or the iCloud container without explicit approval.

## Verification

- `codesign --verify --deep /Applications/zoom.us.app` returns valid.
- Running process shows the shim mapped (non-zero count from `vmmap`).
- The email step advances to password/passkey, avatar renders, New meeting opens.
- The updater plists under `/Library` are named `.disabled`.
- Report cleanup, install and the user's original action separately. Do not call it fixed
  because the app launches.

## Rollback

Remove the shim by reinstalling the official package
(`curl -L 'https://zoom.us/client/latest/Zoom.pkg?archType=arm64'`), which restores a
 genuine signed bundle, then re-enable the `.disabled` launch plists. The ban returns,
which is the expected consequence of dropping the identity substitution.
