#!/bin/bash
# Build the identity shim and the launcher stub into a directory.
# usage: build_shim.sh [outdir]
set -eu
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="${1:-$SRC/build}"
ARCH="$(uname -m)"

mkdir -p "$OUT"

clang -arch "$ARCH" -dynamiclib -O2 -Wall -o "$OUT/zoomidspoof.dylib" "$SRC/zoomidspoof.c" \
      -framework CoreFoundation -framework IOKit
clang -arch "$ARCH" -O2 -Wall -o "$OUT/zoom.us.stub" "$SRC/launcher.c"

codesign --force --sign - "$OUT/zoomidspoof.dylib"
codesign --force --sign - "$OUT/zoom.us.stub"

ls -la "$OUT/zoomidspoof.dylib" "$OUT/zoom.us.stub"
