#!/bin/bash
# Re-apply the identity patch after a manual Zoom update (the updater is disabled,
# so a genuine bundle only reappears if someone replaces Zoom by hand).
#
# Run as root:
#   osascript -e 'do shell script "/bin/bash \"/Library/Application Support/ZoomIdentity/reapply.sh\"" with administrator privileges'
set -u
APP="${ZOOM_APP:-/Applications/zoom.us.app}"
IDENT="${ZOOM_IDENT_DIR:-/Library/Application Support/ZoomIdentity}"
LSR=/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister
LOG=/var/tmp/zoom1132-reapply.log
: >"$LOG"
exec >>"$LOG" 2>&1
echo "=== $(date) reapply ==="
set -x

[ -d "$APP" ] || { echo "Zoom not installed"; exit 1; }
[ -f "$IDENT/zoomidspoof.dylib" ] || { echo "shim missing"; exit 1; }
[ -f "$IDENT/zoom.us.stub" ] || { echo "stub missing"; exit 1; }

killall zoom.us zoom.us.bin caphost CptHost 2>/dev/null
sleep 2

BUILD="$(mktemp -d /var/tmp/zoom1132.XXXXXX)"
trap 'rm -rf "$BUILD"' EXIT
/usr/bin/ditto "$APP" "$BUILD/zoom.us.app"

if [ ! -f "$BUILD/zoom.us.app/Contents/MacOS/zoom.us.bin" ]; then
  cd "$BUILD/zoom.us.app/Contents/MacOS" || exit 1
  mv zoom.us zoom.us.bin
  install -m 0755 "$IDENT/zoom.us.stub" zoom.us
fi

/usr/bin/plutil -remove LSEnvironment "$BUILD/zoom.us.app/Contents/Info.plist" 2>/dev/null || true
xattr -cr "$BUILD/zoom.us.app"
codesign --force --deep --sign - --options runtime --entitlements "$IDENT/entitlements.plist" \
         "$BUILD/zoom.us.app"
codesign --verify --deep "$BUILD/zoom.us.app" || { echo "signing failed"; exit 1; }

rm -rf "$APP"
/usr/bin/ditto "$BUILD/zoom.us.app" "$APP"
chown -R root:wheel "$APP"
chmod -R go-w "$APP"
"$LSR" -f "$APP"

echo "=== reapply done: identity preserved in $IDENT/identity.plist ==="
