/*
 * zoomidspoof.dylib -- present a synthetic hardware identity to one process.
 *
 * Zoom builds its device id from IOPlatformUUID + IOPlatformSerialNumber
 * (see references/evidence.md). Error 1132 is keyed to those values, so they
 * must differ for Zoom while everything else on the machine is unaffected.
 *
 * Identity source, in order: env ZOOMSPOOF_UUID / ZOOMSPOOF_SERIAL /
 * ZOOMSPOOF_BOARDID, then the plist at $ZOOMID_PLIST or the default below.
 *
 * build: clang -arch arm64 -dynamiclib -O2 -o zoomidspoof.dylib zoomidspoof.c \
 *            -framework CoreFoundation -framework IOKit
 */
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <uuid/uuid.h>
#include <sys/time.h>

#define DYLD_INTERPOSE(_replacement, _replacee)                                 \
    __attribute__((used)) static struct {                                       \
        const void *replacement;                                                \
        const void *replacee;                                                   \
    } _interpose_##_replacee __attribute__((section("__DATA,__interpose"))) = { \
        (const void *)(unsigned long)&_replacement,                             \
        (const void *)(unsigned long)&_replacee}

#define DEFAULT_PLIST "/Library/Application Support/ZoomIdentity/identity.plist"

static char g_uuid[64], g_serial[64], g_board[64];
static int  g_ready = 0;

static void load_identity(void)
{
    if (g_ready) return;
    g_ready = 1;

    const char *u = getenv("ZOOMSPOOF_UUID");
    const char *s = getenv("ZOOMSPOOF_SERIAL");
    const char *b = getenv("ZOOMSPOOF_BOARDID");

    if (!u || !s) {
        const char *path = getenv("ZOOMID_PLIST");
        if (!path || !*path) path = DEFAULT_PLIST;
        CFURLRef url = CFURLCreateWithFileSystemPath(kCFAllocatorDefault,
            CFStringCreateWithCString(kCFAllocatorDefault, path, kCFStringEncodingUTF8),
            kCFURLPOSIXPathStyle, false);
        if (url) {
            CFReadStreamRef rs = CFReadStreamCreateWithFile(kCFAllocatorDefault, url);
            if (rs && CFReadStreamOpen(rs)) {
                CFPropertyListRef pl = CFPropertyListCreateWithStream(
                    kCFAllocatorDefault, rs, 0, kCFPropertyListImmutable, NULL, NULL);
                if (pl && CFGetTypeID(pl) == CFDictionaryGetTypeID()) {
                    CFStringRef du = (CFStringRef)CFDictionaryGetValue(pl, CFSTR("IOPlatformUUID"));
                    CFStringRef ds = (CFStringRef)CFDictionaryGetValue(pl, CFSTR("IOPlatformSerialNumber"));
                    CFStringRef db = (CFStringRef)CFDictionaryGetValue(pl, CFSTR("board-id"));
                    if (!u && du && CFStringGetCString(du, g_uuid, sizeof g_uuid, kCFStringEncodingUTF8)) u = g_uuid;
                    if (!s && ds && CFStringGetCString(ds, g_serial, sizeof g_serial, kCFStringEncodingUTF8)) s = g_serial;
                    if (!b && db && CFStringGetCString(db, g_board, sizeof g_board, kCFStringEncodingUTF8)) b = g_board;
                }
                if (pl) CFRelease(pl);
                CFReadStreamClose(rs);
            }
            if (rs) CFRelease(rs);
            CFRelease(url);
        }
    }

    if (u) snprintf(g_uuid, sizeof g_uuid, "%s", u);
    if (s) snprintf(g_serial, sizeof g_serial, "%s", s);
    if (b) snprintf(g_board, sizeof g_board, "%s", b);
}

static const char *spoof_for(CFStringRef key)
{
    if (!key) return NULL;
    char buf[128];
    if (!CFStringGetCString(key, buf, sizeof buf, kCFStringEncodingUTF8)) return NULL;
    if (!strcmp(buf, "IOPlatformUUID") && g_uuid[0])           return g_uuid;
    if (!strcmp(buf, "IOPlatformSerialNumber") && g_serial[0])  return g_serial;
    if (!strcmp(buf, "board-id") && g_board[0])                 return g_board;
    return NULL;
}

/* Non-interposed read path for every property we do not spoof. */
static CFTypeRef read_via_properties(io_registry_entry_t entry, CFStringRef key, CFAllocatorRef alloc)
{
    if (!key) return NULL;
    CFMutableDictionaryRef dict = NULL;
    CFTypeRef out = NULL;
    if (IORegistryEntryCreateCFProperties(entry, &dict, alloc, 0) == KERN_SUCCESS && dict) {
        CFTypeRef v = (CFTypeRef)CFDictionaryGetValue(dict, key);
        if (v) out = CFRetain(v);
        CFRelease(dict);
    }
    return out;
}

static __thread int g_in_hook = 0;

static CFTypeRef my_IORegistryEntryCreateCFProperty(io_registry_entry_t entry, CFStringRef key,
                                                    CFAllocatorRef alloc, IOOptionBits options)
{
    if (g_in_hook) return read_via_properties(entry, key, alloc);
    g_in_hook = 1;
    load_identity();
    CFTypeRef out = NULL;
    const char *v = spoof_for(key);
    if (v) out = CFStringCreateWithCString(alloc, v, kCFStringEncodingUTF8);
    if (!out) out = read_via_properties(entry, key, alloc);
    g_in_hook = 0;
    return out;
}

static CFTypeRef my_IORegistryEntrySearchCFProperty(io_registry_entry_t entry, const io_name_t plane,
                                                    CFStringRef key, CFAllocatorRef alloc, IOOptionBits options)
{
    (void)options;
    if (g_in_hook) return read_via_properties(entry, key, alloc);
    g_in_hook = 1;
    load_identity();
    CFTypeRef out = NULL;
    const char *v = spoof_for(key);
    if (v) {
        out = CFStringCreateWithCString(alloc, v, kCFStringEncodingUTF8);
    } else {
        io_registry_entry_t cursor = entry;
        IOObjectRetain(cursor);
        int guard = 0;
        while (cursor && !out && guard++ < 64) {
            out = read_via_properties(cursor, key, alloc);
            if (out) break;
            io_registry_entry_t parent = 0;
            if (IORegistryEntryGetParentEntry(cursor, plane ? plane : kIOServicePlane, &parent) != KERN_SUCCESS)
                parent = 0;
            IOObjectRelease(cursor);
            cursor = parent;
        }
        if (cursor) IOObjectRelease(cursor);
    }
    g_in_hook = 0;
    return out;
}

static int my_gethostuuid(uuid_t id, const struct timespec *wait)
{
    (void)wait;
    load_identity();
    if (!g_uuid[0]) return -1;
    uuid_t parsed;
    if (uuid_parse(g_uuid, parsed) != 0) return -1;
    memcpy(id, parsed, sizeof(uuid_t));
    return 0;
}

DYLD_INTERPOSE(my_IORegistryEntryCreateCFProperty, IORegistryEntryCreateCFProperty);
DYLD_INTERPOSE(my_IORegistryEntrySearchCFProperty, IORegistryEntrySearchCFProperty);
DYLD_INTERPOSE(my_gethostuuid, gethostuuid);
