#!/usr/bin/env python3
"""Delete all local Zoom Workplace state for the current user.

Records a manifest next to the script (zoom-wipe-manifest.json) with every path,
its size and the outcome. Explicit paths plus per-container prefix matches only:
no wildcard deletions across shared directories.

Does not touch: ~/Documents/Zoom recordings, browser profiles, iCloud containers,
Time Machine, Trash, or macOS accessibility Zoom features.
"""
import json
import os
import shutil
import subprocess

HOME = os.path.expanduser("~")
MANIFEST = os.path.join(os.path.dirname(os.path.abspath(__file__)), "zoom-wipe-manifest.json")


def size_of(path):
    if os.path.islink(path):
        return 0
    if os.path.isfile(path):
        try:
            return os.path.getsize(path)
        except OSError:
            return 0
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def zoom_paths():
    explicit = [
        f"{HOME}/Library/Application Support/zoom.us",
        f"{HOME}/Library/Application Support/ZoomUpdater",
        f"{HOME}/Library/Caches/us.zoom.xos",
        f"{HOME}/Library/Logs/zoom.us",
        f"{HOME}/Library/Logs/ZoomPhone",
        f"{HOME}/Library/Group Containers/BJ4HAAB9B3.ZoomClient3rd",
        f"{HOME}/Library/Application Scripts/BJ4HAAB9B3.ZoomClient3rd",
        f"{HOME}/Library/Saved Application State/us.zoom.xos.savedState",
        f"{HOME}/Library/WebKit/us.zoom.xos",
        f"{HOME}/Library/Preferences/ZoomChat.plist",
    ]
    prefixes = ("us.zoom", "ZoomChat")
    for base in (f"{HOME}/Library/Preferences", f"{HOME}/Library/Preferences/ByHost",
                 f"{HOME}/Library/HTTPStorages", f"{HOME}/Library/Containers",
                 f"{HOME}/Library/Caches"):
        if os.path.isdir(base):
            for name in sorted(os.listdir(base)):
                if name.startswith(prefixes):
                    explicit.append(os.path.join(base, name))
    return sorted(set(explicit))


def per_user_temp():
    found = []
    for key in ("DARWIN_USER_CACHE_DIR", "DARWIN_USER_TEMP_DIR"):
        root = subprocess.run(["getconf", key], capture_output=True, text=True).stdout.strip()
        if not root or not os.path.isdir(root):
            continue
        for dirpath, dirnames, _files in os.walk(root):
            for d in list(dirnames):
                if "us.zoom" in d.lower() or d.lower().startswith("zoom"):
                    found.append(os.path.join(dirpath, d))
                    dirnames.remove(d)
    return sorted(set(found))


def main():
    if subprocess.run(["pgrep", "-x", "zoom.us"], capture_output=True).returncode == 0:
        raise SystemExit("Zoom is running. Quit it first.")

    manifest = []
    for path in zoom_paths() + per_user_temp():
        if not os.path.exists(path) and not os.path.islink(path):
            manifest.append({"path": path, "action": "absent"})
            continue
        entry = {"path": path, "bytes": size_of(path),
                 "type": "dir" if os.path.isdir(path) else "file"}
        try:
            if os.path.isdir(path) and not os.path.islink(path):
                subprocess.run(["chflags", "-R", "nouchg,noschg", path], capture_output=True)
                shutil.rmtree(path)
            else:
                os.remove(path)
            entry["action"] = "deleted"
        except Exception as exc:  # noqa: BLE001
            entry["action"] = f"FAILED: {exc}"
        manifest.append(entry)

    prefs = []
    for domain in ("us.zoom.xos", "us.zoom.ZoomMeeting", "us.zoom.ZoomClips", "us.zoom.updater",
                   "us.zoom.updater.config", "us.zoom.xos.Hotkey", "ZoomChat"):
        rc = subprocess.run(["defaults", "delete", domain], capture_output=True).returncode
        prefs.append({"domain": domain, "deleted": rc == 0})

    keychain = []
    for service in ("Zoom Safe Storage", "Zoom Safe Meeting Storage"):
        subprocess.run(["security", "delete-generic-password", "-s", service, "-a", "Zoom"],
                       capture_output=True)
        rc = subprocess.run(["security", "find-generic-password", "-s", service, "-a", "Zoom"],
                            capture_output=True).returncode
        keychain.append({"service": service, "absent": rc == 44})

    result = {
        "paths": manifest,
        "preference_domains": prefs,
        "keychain": keychain,
        "deleted": sum(1 for m in manifest if m.get("action") == "deleted"),
        "bytes_deleted": sum(m.get("bytes", 0) for m in manifest if m.get("action") == "deleted"),
        "failed": [m["path"] for m in manifest if str(m.get("action", "")).startswith("FAILED")],
    }
    with open(MANIFEST, "w") as fh:
        json.dump(result, fh, indent=2)

    print(f"deleted {result['deleted']} paths, {result['bytes_deleted']:,} bytes")
    for item in manifest:
        if item.get("action") != "absent":
            print(f"  {item['action']:<12} {item.get('bytes', 0):>12,}  {item['path']}")
    print("keychain:", [(k["service"], "absent" if k["absent"] else "STILL PRESENT") for k in keychain])
    if result["failed"]:
        print("protected (expected for empty WebKit temp dirs):", *result["failed"], sep="\n  ")


if __name__ == "__main__":
    main()
