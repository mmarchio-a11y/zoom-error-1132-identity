#!/bin/bash
# Install a genuine Zoom build and patch it with the device-identity shim.
#
# Run as root, normally via:
#   osascript -e 'do shell script "/bin/bash /abs/path/scripts/fix_zoom_1132_root.sh" with administrator privileges'
#
# Env overrides: ZOOM_APP, ZOOM_IDENT_DIR.
set -u

APP="${ZOOM_APP:-/Applications/zoom.us.app}"
IDENT="${ZOOM_IDENT_DIR:-/Library/Application Support/ZoomIdentity}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LSR=/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister
LOG=/var/tmp/zoom1132-install.log

: >"$LOG"
exec >>"$LOG" 2>&1
echo "=== $(date) fix_zoom_1132 start ==="
set -x

[ "$(id -u)" = "0" ] || { echo "must run as root"; exit 1; }

ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  URL="https://zoom.us/client/latest/Zoom.pkg?archType=arm64"
else
  URL="https://zoom.us/client/latest/Zoom.pkg"
fi

WORK="$(mktemp -d /var/tmp/zoom1132.XXXXXX)"
trap 'rm -rf "$WORK"' EXIT

# 1. Official package
curl -fsSL "$URL" -o "$WORK/Zoom.pkg"
SIG="$(pkgutil --check-signature "$WORK/Zoom.pkg")"
echo "$SIG" | grep -q "Developer ID Installer: Zoom" || { echo "unexpected signer"; exit 1; }
echo "$SIG" | grep -q "trusted by the Apple notary service" || { echo "not notarised"; exit 1; }

# 2. Shim + stub
bash "$SRC/build_shim.sh" "$WORK/shim"
cat > "$WORK/entitlements.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>com.apple.security.cs.allow-dyld-environment-variables</key><true/>
    <key>com.apple.security.cs.disable-library-validation</key><true/>
</dict>
</plist>
PLIST

# 3. Pristine bundle from the payload
pkgutil --expand-full "$WORK/Zoom.pkg" "$WORK/expand" >/dev/null 2>&1
SRC_APP="$(find "$WORK/expand" -maxdepth 4 -type d -name 'zoom.us.app' | head -1)"
[ -n "$SRC_APP" ] && [ -d "$SRC_APP" ] || { echo "no app in payload"; exit 1; }
/usr/bin/ditto "$SRC_APP" "$WORK/build/zoom.us.app"
BIN="$WORK/build/zoom.us.app/Contents/MacOS/zoom.us"
lipo -info "$BIN" | grep -q "$ARCH" || { echo "wrong architecture: $(lipo -info "$BIN")"; exit 1; }

# 4. Stub in place of the real executable
cd "$WORK/build/zoom.us.app/Contents/MacOS" || exit 1
mv zoom.us zoom.us.bin
install -m 0755 "$WORK/shim/zoom.us.stub" zoom.us
/usr/bin/plutil -remove LSEnvironment "$WORK/build/zoom.us.app/Contents/Info.plist" 2>/dev/null || true
xattr -cr "$WORK/build/zoom.us.app"
codesign --force --deep --sign - --options runtime --entitlements "$WORK/entitlements.plist" \
         "$WORK/build/zoom.us.app"
codesign --verify --deep "$WORK/build/zoom.us.app" || { echo "signing failed"; exit 1; }
echo "build signed"

# 5. Identity assets. The identity is created once and never rotated.
mkdir -p "$IDENT/source"
if [ ! -f "$IDENT/identity.plist" ]; then
  NEW_UUID="$(python3 -c 'import uuid;print(str(uuid.uuid4()).upper())')"
  NEW_SERIAL="$(python3 -c 'import random,string;print("C02"+"".join(random.choice(string.ascii_uppercase+string.digits) for _ in range(7)))')"
  cat > "$IDENT/identity.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
\t<key>IOPlatformUUID</key>\n\t<string>$NEW_UUID</string>
\t<key>IOPlatformSerialNumber</key>\n\t<string>$NEW_SERIAL</string>
</dict>
</plist>
PLIST
  echo "new identity: $NEW_UUID / $NEW_SERIAL"
else
  echo "keeping existing identity"
fi
chmod 0644 "$IDENT/identity.plist"; chown root:wheel "$IDENT/identity.plist"
install -m 0644 -o root -g wheel "$WORK/shim/zoomidspoof.dylib" "$IDENT/zoomidspoof.dylib"
install -m 0644 -o root -g wheel "$WORK/entitlements.plist"     "$IDENT/entitlements.plist"
install -m 0755 -o root -g wheel "$WORK/shim/zoom.us.stub"      "$IDENT/zoom.us.stub"
install -m 0755 -o root -g wheel "$SRC/reapply_after_update.sh" "$IDENT/reapply.sh"
install -m 0644 -o root -g wheel "$SRC/zoomidspoof.c"           "$IDENT/source/zoomidspoof.c"
install -m 0644 -o root -g wheel "$SRC/launcher.c"              "$IDENT/source/launcher.c"

# 6. Official installer (brings receipts and helper), then replace the bundle
/usr/sbin/installer -pkg "$WORK/Zoom.pkg" -target / || echo "WARN installer failed, continuing"
killall zoom.us zoom.us.bin caphost CptHost 2>/dev/null
sleep 3

rm -rf "$APP"
/usr/bin/ditto "$WORK/build/zoom.us.app" "$APP"
chown -R root:wheel "$APP"
chmod -R go-w "$APP"
"$LSR" -f "$APP"

# 7. Zoom's updater would overwrite the patched bundle
for p in /Library/LaunchAgents/us.zoom.updater.plist \
         /Library/LaunchAgents/us.zoom.updater.login.check.plist \
         /Library/LaunchDaemons/us.zoom.ZoomDaemon.plist; do
  [ -f "$p" ] && mv -f "$p" "$p.disabled"
done
CONSOLE_UID="$(stat -f %u /dev/console)"
launchctl disable "gui/$CONSOLE_UID/us.zoom.updater" 2>/dev/null
launchctl disable "gui/$CONSOLE_UID/us.zoom.updater.login.check" 2>/dev/null
launchctl disable system/us.zoom.ZoomDaemon 2>/dev/null

codesign --verify --deep "$APP" && echo "verify ok"
ls -la "$APP/Contents/MacOS" "$IDENT"
echo "=== fix_zoom_1132 done ==="
