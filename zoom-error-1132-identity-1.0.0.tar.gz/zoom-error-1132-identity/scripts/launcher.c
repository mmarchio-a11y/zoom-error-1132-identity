/*
 * zoom.us -- launcher stub installed as the Zoom bundle executable.
 *
 * Sets DYLD_INSERT_LIBRARIES and execs Contents/MacOS/zoom.us.bin, so Dock,
 * Finder, zoommtg:// links and Zoom's own relaunch all pass through it with no
 * wrapper app or background agent.
 *
 * LSEnvironment in Info.plist cannot do this: LaunchServices refuses to open an
 * app whose LSEnvironment contains DYLD_* (error -10669).
 *
 * build: clang -arch arm64 -O2 -o zoom.us launcher.c
 */
#include <mach-o/dyld.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#define DEFAULT_SHIM "/Library/Application Support/ZoomIdentity/zoomidspoof.dylib"
#define REAL_BINARY  "zoom.us.bin"

int main(int argc, char **argv)
{
    (void)argc;

    char self[PATH_MAX];
    uint32_t size = sizeof(self);
    if (_NSGetExecutablePath(self, &size) != 0) {
        fprintf(stderr, "zoom launcher: cannot resolve own path\n");
        return 127;
    }

    char resolved[PATH_MAX];
    if (!realpath(self, resolved)) {
        strncpy(resolved, self, sizeof(resolved) - 1);
        resolved[sizeof(resolved) - 1] = '\0';
    }

    char dir[PATH_MAX];
    strncpy(dir, resolved, sizeof(dir) - 1);
    dir[sizeof(dir) - 1] = '\0';
    char *slash = strrchr(dir, '/');
    if (slash) *slash = '\0';

    char real[PATH_MAX];
    snprintf(real, sizeof(real), "%s/%s", dir, REAL_BINARY);

    if (access(real, X_OK) != 0) {
        fprintf(stderr, "zoom launcher: missing %s\n", real);
        return 127;
    }

    const char *existing = getenv("DYLD_INSERT_LIBRARIES");
    if (!existing || !*existing) {
        const char *shim = getenv("ZOOMID_SHIM");
        setenv("DYLD_INSERT_LIBRARIES", (shim && *shim) ? shim : DEFAULT_SHIM, 1);
    }

    argv[0] = resolved;
    execv(real, argv);

    fprintf(stderr, "zoom launcher: exec failed for %s: %s\n", real, strerror(errno));
    return 127;
}
