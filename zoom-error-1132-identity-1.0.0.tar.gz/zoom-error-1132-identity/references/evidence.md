# Evidence: 1132 is a hardware-identity ban

## From the Zoom bundle

`Contents/Frameworks/cmmbiz.framework` on macOS 7.2.5 contains, in one cluster:

```
GetMachineMacAddress, sysctl mgmtInfoBase failure
%02X:%02X:%02X:%02X:%02X:%02X
IOPlatformUUID
ZITPackage
Preferences/us.zoom.config.plist
Managed Preferences/us.zoom.config.plist
IOPlatformSerialNumber
%@%@
```

`IOPlatformExpertDevice`, `IOPlatformUUID` and `IOPlatformSerialNumber` also appear in
`zCCIMeeting.dylib`, `libzmbTranscode.dylib`, `zSIPCallUI` and `libzmbRecord.dylib`.
`%@%@` next to the serial is the concatenation that forms the device id.

Verify with:

```
cd /Applications/zoom.us.app
grep -rao --binary-files=text -E "IOPlatform[A-Za-z]*" . | awk -F: '{print $2}' | sort | uniq -c
grep -ral --binary-files=text "IOPlatformUUID" .
```

## From the workaround apps

The 1132 Fixer macOS app launches Zoom under `sandbox-exec` with a profile whose only
relevant rules are:

```
(deny iokit-get-properties
    (iokit-property "IOPlatformSerialNumber")
    (iokit-property "IOPlatformUUID")
    (iokit-property "board-id")
    (iokit-property "IOMACAddress"))
(deny file-read-data (literal "/Library/Preferences/SystemConfiguration/NetworkInterfaces.plist"))
```

Denying the reads is enough to clear the sign-in error, which proves the server keys on
them. It also explains the degraded result: Zoom receives empty values, so the session
is anonymous-ish (joins work, avatar and hosting do not).

## From behaviour

| Observation | Meaning |
|---|---|
| Deleting every file, cache, plist and Keychain item changes nothing | State is not stored locally |
| Clean reinstall from an official package changes nothing | The app reads the value live from IOKit at every launch |
| A different Mac or a fresh VM signs in with the same account | The account is fine; the device is blocked |
| Support appeal "accepted" yet the Mac stays blocked | The ban row is keyed to the hardware fingerprint |
| Sandboxed launch signs in but loses avatar and hosting | Empty identity produces a restricted session |

## What the fix changes

`zoomidspoof.dylib` interposes `IORegistryEntryCreateCFProperty`,
`IORegistryEntrySearchCFProperty` and `gethostuuid` inside Zoom processes only, returning
fixed values for `IOPlatformUUID`, `IOPlatformSerialNumber` and `board-id` from
`/Library/Application Support/ZoomIdentity/identity.plist`. Every other process still sees
real hardware, and nothing is written to NVRAM or the device tree.

Unspoofed keys are served by `IORegistryEntryCreateCFProperties` (a different symbol,
not interposed). Calling the original through `dlsym` does not work: dyld's interposing
table makes `RTLD_NEXT`, `RTLD_DEFAULT` and `dlopen`-then-`dlsym` all resolve back to the
interposer, producing infinite recursion (observed as a stack of thousands of frames in
`sample`).

## Wiring

```
/Applications/zoom.us.app/Contents/MacOS/zoom.us       stub, sets DYLD_INSERT_LIBRARIES, execv
/Applications/zoom.us.app/Contents/MacOS/zoom.us.bin   Zoom's real executable
/Library/Application Support/ZoomIdentity/zoomidspoof.dylib
/Library/Application Support/ZoomIdentity/identity.plist
```

The bundle is signed ad hoc with hardened runtime plus
`com.apple.security.cs.allow-dyld-environment-variables` and
`com.apple.security.cs.disable-library-validation`, without which dyld strips the
injection and refuses the unsigned library.

Rejected alternatives: `LSEnvironment` in Info.plist (LaunchServices error -10669),
a wrapper app (breaks zoommtg:// URLs and Dock behaviour), editing inside
`/Applications` directly (App Management denies it even for root).
